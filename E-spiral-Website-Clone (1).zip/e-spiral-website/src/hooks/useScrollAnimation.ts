"use client"

import { useEffect, useRef, useState } from 'react'

export function useScrollAnimation<T extends HTMLElement = HTMLElement>(threshold = 0.1) {
  const [isVisible, setIsVisible] = useState(false)
  const elementRef = useRef<T>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsVisible(entry.isIntersecting)
      },
      { threshold }
    )

    const currentElement = elementRef.current
    if (currentElement) {
      observer.observe(currentElement)
    }

    return () => {
      if (currentElement) {
        observer.unobserve(currentElement)
      }
    }
  }, [threshold])

  return { elementRef, isVisible }
}

export function useScrollProgress() {
  const [scrollProgress, setScrollProgress] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.pageYOffset
      const docHeight = document.documentElement.scrollHeight - window.innerHeight
      const progress = scrollTop / docHeight
      setScrollProgress(Math.min(Math.max(progress, 0), 1))
    }

    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return scrollProgress
}

export function useParallax<T extends HTMLElement = HTMLElement>(speed = 0.5) {
  const [offset, setOffset] = useState(0)
  const elementRef = useRef<T>(null)

  useEffect(() => {
    const handleScroll = () => {
      if (elementRef.current) {
        const scrollTop = window.pageYOffset
        const elementTop = elementRef.current.offsetTop
        const elementHeight = elementRef.current.offsetHeight
        const windowHeight = window.innerHeight

        // Only apply parallax when element is in viewport
        if (scrollTop + windowHeight > elementTop && scrollTop < elementTop + elementHeight) {
          const newOffset = (scrollTop - elementTop) * speed
          setOffset(newOffset)
        }
      }
    }

    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [speed])

  return { elementRef, offset }
}
