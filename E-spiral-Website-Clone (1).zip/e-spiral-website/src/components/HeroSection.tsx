"use client"

import { Logo } from './Logo'

export function HeroSection() {
  return (
    <section className="hero-bg-frank relative h-screen flex flex-col justify-center items-center pt-24 pb-12">
      {/* ブランド名・ロゴ */}
      <div className="flex items-center space-x-4 mb-6">
        {/* 必要なら超極小ロゴもOK */}
        {/* <Logo size="sm" className="w-10 h-10" /> */}
        <span className="hero-brand-en tracking-wider uppercase">E-spiral</span>
      </div>

      {/* キーメッセージ */}
      <h1 className="hero-main-copy text-center leading-tight">
        未知の自分に出逢いましょう
      </h1>

      {/* CTAボタン */}
      <div className="mt-12 flex justify-center">
        <button className="hero-button-frank">
          無料で相談してみる
        </button>
      </div>

      {/* スクロール誘導 */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center opacity-70">
        <div className="w-7 h-10 border-2 border-teal-400 rounded-full flex items-center justify-center">
          <div className="w-1 h-3 bg-teal-400 rounded-full animate-pulse mt-2" />
        </div>
        <span className="mt-2 text-teal-600 text-xs tracking-widest">スクロール</span>
      </div>
    </section>
  )
}
