import Image from 'next/image'

interface LogoProps {
  className?: string
  size?: 'sm' | 'md' | 'lg'
}

export function Logo({ className = '', size = 'md' }: LogoProps) {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-16 h-16',
    lg: 'w-24 h-24'
  }

  return (
    <div className={`${sizeClasses[size]} ${className}`}>
      {/* E-spiralロゴのSVG */}
      <svg viewBox="0 0 400 400" className="w-full h-full">
        {/* 青緑色の背景 */}
        <rect width="400" height="400" fill="#7DD3C0"/>

        {/* 黄色のスパイラル */}
        <g transform="translate(200,200)">
          {/* 白い矢印 */}
          <path d="M -80 -80 L 80 80 M 60 60 L 80 80 L 60 100"
                stroke="white"
                strokeWidth="4"
                fill="none"/>

          {/* 黄色のスパイラル楕円 */}
          <ellipse cx="-60" cy="-60" rx="15" ry="35"
                   fill="none"
                   stroke="#FDB748"
                   strokeWidth="4"
                   transform="rotate(-45)"/>
          <ellipse cx="-40" cy="-40" rx="20" ry="45"
                   fill="none"
                   stroke="#FDB748"
                   strokeWidth="4"
                   transform="rotate(-45)"/>
          <ellipse cx="-20" cy="-20" rx="25" ry="55"
                   fill="none"
                   stroke="#FDB748"
                   strokeWidth="4"
                   transform="rotate(-45)"/>
          <ellipse cx="0" cy="0" rx="30" ry="65"
                   fill="none"
                   stroke="#FDB748"
                   strokeWidth="4"
                   transform="rotate(-45)"/>
          <ellipse cx="20" cy="20" rx="35" ry="75"
                   fill="none"
                   stroke="#FDB748"
                   strokeWidth="4"
                   transform="rotate(-45)"/>
          <ellipse cx="40" cy="40" rx="40" ry="85"
                   fill="none"
                   stroke="#FDB748"
                   strokeWidth="4"
                   transform="rotate(-45)"/>
        </g>

        {/* E-SPIRAL テキスト */}
        <text x="200" y="350"
              textAnchor="middle"
              fill="white"
              fontSize="32"
              fontWeight="bold"
              fontFamily="Arial, sans-serif">
          E-SPIRAL
        </text>
      </svg>
    </div>
  )
}
