"use client"

import { useScrollAnimation } from '@/hooks/useScrollAnimation'
import type { ReactNode } from 'react'

interface AnimatedSectionProps {
  children: ReactNode
  className?: string
  animation?: 'fadeUp' | 'fadeLeft' | 'fadeRight' | 'scale' | 'blur'
  delay?: number
  threshold?: number
}

export function AnimatedSection({
  children,
  className = '',
  animation = 'fadeUp',
  delay = 0,
  threshold = 0.1
}: AnimatedSectionProps) {
  const { elementRef, isVisible } = useScrollAnimation<HTMLDivElement>(threshold)

  const animationClasses = {
    fadeUp: isVisible
      ? 'opacity-100 translate-y-0'
      : 'opacity-0 translate-y-12',
    fadeLeft: isVisible
      ? 'opacity-100 translate-x-0'
      : 'opacity-0 -translate-x-12',
    fadeRight: isVisible
      ? 'opacity-100 translate-x-0'
      : 'opacity-0 translate-x-12',
    scale: isVisible
      ? 'opacity-100 scale-100'
      : 'opacity-0 scale-95',
    blur: isVisible
      ? 'opacity-100 blur-0'
      : 'opacity-0 blur-sm'
  }

  return (
    <div
      ref={elementRef}
      className={`transition-all duration-1000 ease-out ${animationClasses[animation]} ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  )
}

interface StaggeredTextProps {
  text: string
  className?: string
  delay?: number
}

export function StaggeredText({ text, className = '', delay = 100 }: StaggeredTextProps) {
  const { elementRef, isVisible } = useScrollAnimation<HTMLSpanElement>()
  const words = text.split(' ')

  return (
    <span ref={elementRef} className={className}>
      {words.map((word, index) => (
        <span
          key={`word-${index}-${word}`}
          className={`inline-block transition-all duration-700 ease-out ${
            isVisible
              ? 'opacity-100 translate-y-0'
              : 'opacity-0 translate-y-4'
          }`}
          style={{ transitionDelay: `${index * delay}ms` }}
        >
          {word}
          {index < words.length - 1 && ' '}
        </span>
      ))}
    </span>
  )
}

interface ProgressBarProps {
  className?: string
}

export function ScrollProgressBar({ className = '' }: ProgressBarProps) {
  const { elementRef, isVisible } = useScrollAnimation<HTMLDivElement>()

  return (
    <div ref={elementRef} className={`h-1 bg-gray-200 rounded-full overflow-hidden ${className}`}>
      <div
        className={`h-full bg-gradient-to-r from-brand-teal to-brand-gold transition-all duration-1000 ease-out ${
          isVisible ? 'w-full' : 'w-0'
        }`}
      />
    </div>
  )
}