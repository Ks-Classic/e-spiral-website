"use client"

import { useState, useEffect } from 'react'

export function PsychologicalCTA() {
  const [scrollDepth, setScrollDepth] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.pageYOffset
      const docHeight = document.documentElement.scrollHeight - window.innerHeight
      const scrollPercent = scrollTop / docHeight
      setScrollDepth(scrollPercent)
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // Heroテーマに統一したカード基調スタイル
  const cardStyle =
    'shadow-xl border border-teal-100 bg-white rounded-2xl px-6 py-5 transition-all duration-400 flex flex-col items-center backdrop-blur-lg'
  const labelStyle = 'bg-teal-50 text-teal-600 rounded-full px-3 py-1 text-xs font-key-jp mb-2 inline-block'
  const btnStyle =
    'hero-button-frank w-full mt-2 text-base font-bold py-3 px-6 focus:outline-none focus:ring-2 focus:ring-teal-300 ring-offset-2 ring-offset-white transition'

  // 1. Entry段階
  if (scrollDepth < 0.33) {
    return (
      <div className="fixed bottom-7 right-7 z-50 max-w-xs min-w-[250px]">
        <div className={cardStyle}>
          <div className={labelStyle}>まずは無料診断</div>
          <h3 className="font-key-jp text-base mb-1">あなたの強み・可能性を知る</h3>
          <button className={btnStyle}>今すぐチェック</button>
        </div>
      </div>
    )
  }

  // 2. 中間段階
  if (scrollDepth < 0.66) {
    return (
      <div className="fixed bottom-7 right-7 z-50 max-w-xs min-w-[250px]">
        <div className={cardStyle}>
          <div className={labelStyle}>体験セッション受付中</div>
          <h3 className="font-key-jp text-base mb-1">まずは納得できる体験を</h3>
          <button className={btnStyle}>無料セッション予約</button>
        </div>
      </div>
    )
  }

  // 3. 高コミット段階
  return (
    <div className="fixed bottom-7 right-7 z-50 max-w-xs min-w-[250px]">
      <div className={cardStyle + ' border-2 border-brand-teal shadow-xl'}>
        <div className={labelStyle + ' bg-brand-teal text-white'}>限定受付</div>
        <h3 className="font-key-jp text-base mb-1">180日間プログラム</h3>
        <p className="text-xs text-gray-500 mb-3 mt-1">じっくりサポート・無理な勧誘なし・返金保証あり</p>
        <button className={btnStyle + ' bg-key-hero-deep hover:bg-teal-700'}>プログラム詳細</button>
      </div>
    </div>
  )
}
