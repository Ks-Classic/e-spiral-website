import { Navigation } from '@/components/Navigation'
import { HeroSection } from '@/components/HeroSection'
import { PsychologicalCTA } from '@/components/PsychologicalCTA'
import { AnimatedSection, StaggeredText } from '@/components/AnimatedSection'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'

export default function Home() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <HeroSection />
      <PsychologicalCTA />

      {/* Why E-spiral Section */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-white/90 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto">
          <AnimatedSection className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-6xl text-gray-800 mb-8">
              Why E-Spiral？
            </h2>
            <div className="inline-block p-8 card-elevated mb-8">
              <p className="text-2xl font-heading text-cosmic">
                真の変革は、あなた自身の内からしか生まれ得ない
              </p>
            </div>
            <StaggeredText
              text="あなたの「未知」を、真の「知」へと昇華させる場所。"
              className="text-2xl md:text-3xl text-brand-gradient font-heading mb-8"
            />
          </AnimatedSection>

          <div className="max-w-none text-gray-700 leading-relaxed text-lg md:text-xl space-y-8">
            <AnimatedSection animation="fadeUp" delay={200}>
              <p>
                もし、あなたが今、これまでの成功のその先に、静かなる「未知」を感じているのなら。<br />
                そして、その「未知」の領域へ、本質的なアプローチで足を踏み入れたいと願うのなら。<br />
                E-Spiralは、あなたのその探求心に応えるために存在します。
              </p>
            </AnimatedSection>

            <AnimatedSection animation="fadeUp" delay={400}>
              <p>
                私たちは、単なる解決策や一時的なスキル提供の場ではありません。<br />
                E-Spiralが提供するのは、あなたの深い洞察力に寄り添い、<strong className="text-brand-teal">「未知を知りたい」という根源的な問いへの、「真摯な伴走」</strong>です。
              </p>
            </AnimatedSection>

            <p className="text-reveal">
              E-Spiralには、あなたと同じく、既存の枠を超え、本質的な成長を求める同志が集います。<br />
              「未知を知りたい」という純粋な探求心で結ばれ、互いに刺激し合い、高め合う。<br />
              ここは、真の探求者たちが集う、高次元な知的空間です。
            </p>

            <div className="text-center mt-16">
              <p className="text-2xl text-brand-teal font-heading mb-4">
                さあ、あなたの知的好奇心が本当に求める「未知」へ、共に歩み出しましょう。
              </p>
              <p className="text-xl text-gray-600">
                E-Spiralは、あなたを心からお待ちしています。
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How E-spiral Section */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-teal-50 to-gold-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="font-display text-4xl md:text-6xl text-gray-800 mb-8">
              How E-Spiral
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto font-body">
              本質的な変革のためのプロセス
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-12">
              <div className="card-elevated p-8">
                <h3 className="text-2xl font-heading text-gray-800 mb-6 text-brand-gradient">
                  深層探求メソッド
                </h3>
                <p className="text-lg text-gray-600 leading-relaxed font-body">
                  表面的な課題解決ではなく、あなたの思考の根底に潜む本質的な動機と価値観を探求します。
                  長年の経験で培われた直感と論理思考を統合し、新たな洞察を生み出すプロセスです。
                </p>
              </div>

              <div className="card-elevated p-8">
                <h3 className="text-2xl font-heading text-gray-800 mb-6 text-gold-gradient">
                  対話的コーチング
                </h3>
                <p className="text-lg text-gray-600 leading-relaxed font-body">
                  一方的な指導ではなく、深い対話を通じてあなた自身の答えを引き出します。
                  私たちは問いかけ、あなたは探求する。この相互作用こそが真の変革の鍵です。
                </p>
              </div>

              <div className="card-elevated p-8">
                <h3 className="text-2xl font-heading text-gray-800 mb-6 text-cosmic">
                  継続的伴走
                </h3>
                <p className="text-lg text-gray-600 leading-relaxed font-body">
                  短期的な解決策ではなく、長期的な成長を見据えた継続的なサポートを提供します。
                  あなたの変化に寄り添い、新たな挑戦を共に創造していきます。
                </p>
              </div>
            </div>

            <div className="relative">
              <div className="aspect-square bg-gradient-to-br from-brand-teal/20 to-brand-gold/20 rounded-3xl flex items-center justify-center p-12 card-elevated">
                <div className="text-center space-y-8">
                  <div className="glass-effect rounded-full p-8 backdrop-blur-sm transform hover:scale-105 transition-transform duration-300">
                    <span className="text-2xl font-heading text-brand-teal">深層探求</span>
                  </div>

                  <div className="flex justify-center space-x-6">
                    <div className="glass-effect rounded-full p-6 backdrop-blur-sm transform hover:scale-105 transition-transform duration-300">
                      <span className="text-lg font-ui text-brand-gold">対話</span>
                    </div>
                    <div className="glass-effect rounded-full p-6 backdrop-blur-sm transform hover:scale-105 transition-transform duration-300">
                      <span className="text-lg font-ui text-gray-700">洞察</span>
                    </div>
                  </div>

                  <div className="glass-effect rounded-full p-8 backdrop-blur-sm transform hover:scale-105 transition-transform duration-300">
                    <span className="text-2xl font-heading text-cosmic">継続的伴走</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <AnimatedSection className="text-center mb-20">
            <h2 className="font-display text-4xl md:text-6xl text-gray-800 mb-4">Service</h2>
            <p className="text-xl text-gray-600 font-body">4つのステップで未知の自分を発見</p>
          </AnimatedSection>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <AnimatedSection animation="scale" delay={0}>
              <Card className="card-elevated text-center p-8 group">
                <CardContent className="pt-8">
                  <div className="flex flex-col items-center mb-6">
                    <div className="flex items-center justify-center w-20 h-20 bg-gradient-to-br from-brand-teal to-teal-600 rounded-full mb-0 group-hover:scale-110 transition-transform duration-300">
                      <svg width="20" height="20" viewBox="0 0 32 32" className="mr-2" aria-hidden="true" style={{width: 20, height: 20}}>
                        <circle cx="16" cy="16" r="12" fill="#47C9AF" opacity="0.18" />
                        <ellipse cx="16" cy="16" rx="10" ry="7" fill="none" stroke="#14b8a6" strokeWidth="2.5" />
                        <circle cx="16" cy="16" r="4" fill="#2dd4bf" stroke="#134e4a" strokeWidth="1" />
                      </svg>
                      <span className="text-3xl font-bold text-white">01</span>
                    </div>
                  </div>
                  <h3 className="text-xl font-heading text-gray-800 mb-4">能力の輪の発見</h3>
                  <p className="text-gray-600 font-body">あなたの潜在的な才能と能力の範囲を明確にします</p>
                </CardContent>
              </Card>
            </AnimatedSection>

            <AnimatedSection animation="scale" delay={200}>
              <Card className="card-elevated text-center p-8 group">
                <CardContent className="pt-8">
                  <div className="flex flex-col items-center mb-6">
                    <div className="flex items-center justify-center w-20 h-20 bg-gradient-to-br from-brand-gold to-gold-600 rounded-full mb-0 group-hover:scale-110 transition-transform duration-300">
                      <svg width="20" height="20" viewBox="0 0 32 32" className="mr-2" aria-hidden="true" style={{width: 20, height: 20}}>
                        <circle cx="16" cy="16" r="12" fill="#FDB748" opacity="0.20" />
                        <path d="M16 10a5 5 0 100 10 5 5 0 100-10z" fill="#FDB748" />
                        <polygon points="16,8 19,14 13,14" fill="#fff9c4"/>
                        <circle cx="16" cy="16" r="2.6" fill="#fde68a" />
                      </svg>
                      <span className="text-3xl font-bold text-white">02</span>
                    </div>
                  </div>
                  <h3 className="text-xl font-heading text-gray-800 mb-4">存在の定義</h3>
                  <p className="text-gray-600 font-body">本当のあなたとは何かを深く探求し定義します</p>
                </CardContent>
              </Card>
            </AnimatedSection>

            <AnimatedSection animation="scale" delay={400}>
              <Card className="card-elevated text-center p-8 group">
                <CardContent className="pt-8">
                  <div className="flex flex-col items-center mb-6">
                    <div className="flex items-center justify-center w-20 h-20 bg-gradient-to-br from-deep-teal to-mystic-purple rounded-full mb-0 group-hover:scale-110 transition-transform duration-300">
                      <svg width="20" height="20" viewBox="0 0 32 32" className="mr-2" aria-hidden="true" style={{width: 20, height: 20}}>
                        <rect x="7" y="20" width="18" height="2" rx="1" fill="#4c1d95" />
                        <circle cx="23" cy="21" r="3" fill="#8b5cf6" />
                        <circle cx="9" cy="21" r="1.5" fill="#33dbc9" />
                        <rect x="14" y="8" width="4" height="2" rx="0.8" fill="#bdaaff" />
                      </svg>
                      <span className="text-3xl font-bold text-white">03</span>
                    </div>
                  </div>
                  <h3 className="text-xl font-heading text-gray-800 mb-4">レバレッジポイントの特定</h3>
                  <p className="text-gray-600 font-body">最小の努力で最大の成果を生む重要なポイントを見つけます</p>
                </CardContent>
              </Card>
            </AnimatedSection>

            <AnimatedSection animation="scale" delay={600}>
              <Card className="card-elevated text-center p-8 group">
                <CardContent className="pt-8">
                  <div className="flex flex-col items-center mb-6">
                    <div className="flex items-center justify-center w-20 h-20 bg-gradient-to-br from-cosmic-blue to-brand-teal rounded-full mb-0 group-hover:scale-110 transition-transform duration-300">
                      <svg width="20" height="20" viewBox="0 0 32 32" className="mr-2" aria-hidden="true" style={{width: 20, height: 20}}>
                        <defs>
                          <linearGradient id="goal-grad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#FDB748"/>
                            <stop offset="100%" stopColor="#1e3a8a"/>
                          </linearGradient>
                        </defs>
                        <path d="M8 22 L16 10 L24 22 Z" fill="url(#goal-grad)" opacity="0.17" />
                        <circle cx="16" cy="10" r="2.5" fill="#FDB748" stroke="#1e3a8a" strokeWidth="1" />
                        <rect x="15.5" y="4" width="1" height="8" fill="#1e3a8a" />
                        <polygon points="14,4 18,4 16,2" fill="#FDB748" />
                      </svg>
                      <span className="text-3xl font-bold text-white">04</span>
                    </div>
                  </div>
                  <h3 className="text-xl font-heading text-gray-800 mb-4">究極のゴール設定</h3>
                  <p className="text-gray-600 font-body">人生における真の目標と方向性を設定します</p>
                </CardContent>
              </Card>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* 受講者の声 Section */}
      <section id="testimonials" className="py-24 px-4 sm:px-6 lg:px-8 bg-key-hero-mint">
        <div className="max-w-6xl mx-auto">
          <AnimatedSection className="text-center mb-20">
            <h2 className="font-display text-4xl md:text-6xl text-gray-800 mb-4">受講者の声</h2>
            <p className="text-xl text-gray-600 font-body">E-spiralで「未知の自分」に出逢った方々</p>
          </AnimatedSection>

          <div className="grid md:grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Voice 1 */}
            <AnimatedSection animation="fadeUp" delay={0}>
              <Card className="card-elevated p-8 h-full group">
                <CardContent className="pt-6">
                  <div className="flex items-center mb-4">
                    {/* Placeholder Icon */}
                    <div className="w-12 h-12 rounded-full bg-teal-100 flex items-center justify-center mr-4">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-brand-teal"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.04 3 5.5l7 7Z"/></svg>
                    </div>
                    <div>
                      <h4 className="font-heading text-lg text-gray-800">A.S様</h4>
                      <p className="text-sm text-gray-500">30代・企画職</p>
                    </div>
                  </div>
                  <p className="text-gray-700 font-body text-base leading-relaxed">
                    「長年ぼんやりと感じていたキャリアの閉塞感。E-spiralのプログラムで自分の強みと本当にやりたい事が明確になり、新しい挑戦への一歩を踏み出せました。もっと早く相談すればよかったです！」
                  </p>
                </CardContent>
              </Card>
            </AnimatedSection>
            {/* Voice 2 */}
            <AnimatedSection animation="fadeUp" delay={200}>
              <Card className="card-elevated p-8 h-full group">
                <CardContent className="pt-6">
                  <div className="flex items-center mb-4">
                     <div className="w-12 h-12 rounded-full bg-gold-100 flex items-center justify-center mr-4">
                       <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-brand-gold"><circle cx="12" cy="12" r="10" /><path d="m9 12 2 2 4-4" /></svg>
                    </div>
                    <div>
                      <h4 className="font-heading text-lg text-gray-800">K.T様</h4>
                      <p className="text-sm text-gray-500">40代・経営者</p>
                    </div>
                  </div>
                  <p className="text-gray-700 font-body text-base leading-relaxed">
                    「事業の次のステージを模索していた際、E-spiralのコーチングに出会いました。思考が整理され、自社のレバレッジポイントが明確に。おかげでチーム全体の士気も上がり、具体的なアクションに繋がっています。」
                  </p>
                </CardContent>
              </Card>
            </AnimatedSection>
            {/* Voice 3 */}
            <AnimatedSection animation="fadeUp" delay={400}>
              <Card className="card-elevated p-8 h-full group">
                <CardContent className="pt-6">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 rounded-full bg-indigo-100 flex items-center justify-center mr-4">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-indigo-500"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></svg>
                    </div>
                    <div>
                      <h4 className="font-heading text-lg text-gray-800">M.Y様</h4>
                      <p className="text-sm text-gray-500">20代・フリーランス</p>
                    </div>
                  </div>
                  <p className="text-gray-700 font-body text-base leading-relaxed">
                    「自分の『好き』を仕事にしたいけれど、何から手をつけていいか分からず…。セッションを通じて、自分の価値観や才能を再発見。今では自信を持って自分のサービスを提供できるようになりました。」
                  </p>
                </CardContent>
              </Card>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Coach Section */}
      <section id="coach" className="py-24 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-6xl mx-auto">
          <AnimatedSection className="text-center mb-20">
            <h2 className="font-display text-4xl md:text-6xl text-gray-800 mb-4">Our Coaches</h2>
            <p className="text-xl text-gray-600 font-body">あなたの「未知」への旅を伴走します</p>
          </AnimatedSection>

          <div className="grid md:grid-cols-2 gap-12 lg:gap-16 items-start">
            {/* Coach 1 */}
            <AnimatedSection animation="fadeUp" delay={0}>
              <Card className="card-elevated text-center p-8 group">
                {/* Placeholder Image - User should upload actual images */}
                <div className="w-32 h-32 rounded-full bg-teal-100 mx-auto mb-6 flex items-center justify-center group-hover:shadow-lg transition-shadow">
                   <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="text-brand-teal opacity-80"><circle cx="12" cy="7" r="4"></circle><path d="M5.5 22v-2a4 4 0 0 1 4-4h5a4 4 0 0 1 4 4v2"></path></svg>
                </div>
                <h3 className="text-2xl font-heading text-gray-800 mb-2">関奈津美</h3>
                <p className="text-brand-teal font-semibold mb-4">プロフェッショナルコーチ / ファウンダー</p>
                <p className="text-gray-600 font-body text-sm leading-relaxed">
                  深い洞察力と共感力で、クライアントの内なる声に耳を傾け、本質的な変革をサポート。個人の潜在能力を最大限に引き出すことを得意とする。
                </p>
              </Card>
            </AnimatedSection>
            {/* Coach 2 */}
            <AnimatedSection animation="fadeUp" delay={200}>
              <Card className="card-elevated text-center p-8 group">
                 <div className="w-32 h-32 rounded-full bg-gold-100 mx-auto mb-6 flex items-center justify-center group-hover:shadow-lg transition-shadow">
                   <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" className="text-brand-gold opacity-80"><circle cx="12" cy="7" r="4"></circle><path d="M5.5 22v-2a4 4 0 0 1 4-4h5a4 4 0 0 1 4 4v2"></path></svg>
                </div>
                <h3 className="text-2xl font-heading text-gray-800 mb-2">友松絵里</h3>
                <p className="text-brand-gold font-semibold mb-4">プロフェッショナルコーチ / プロセスコンダクター</p>
                <p className="text-gray-600 font-body text-sm leading-relaxed">
                  プロセスコンダクターとして、相手の無自覚な思考癖や行動癖を的確に把握し、クライアントが心から望む「ありたい姿」の実現を力強く後押しする。
                </p>
              </Card>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-hero relative">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-display text-4xl md:text-6xl text-white mb-8 text-glow">
            未知の自分に出逢いませんか？
          </h2>
          <p className="text-xl md:text-2xl text-white/90 mb-12 font-body leading-relaxed">
            まずは気軽に無料でご相談いただけます
          </p>

          <div className="space-y-6">
            <button className="btn-cosmic text-2xl px-16 py-6">
              無料で相談してみる
            </button>
            <p className="text-white/70 font-ui">
              ※ 限定20名様まで無料カウンセリング実施中
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-12">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-brand-teal rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-xl">E</span>
                </div>
                <span className="text-2xl font-bold font-ui">E-SPIRAL</span>
              </div>
              <p className="text-gray-300 font-body leading-relaxed">
                未知の自分との出逢いをサポートする<br />
                ウェルネスカンパニー
              </p>
            </div>

            <div>
              <h3 className="text-xl font-heading mb-6">Services</h3>
              <ul className="space-y-3 text-gray-300 font-body">
                <li>能力の輪の発見</li>
                <li>存在の定義</li>
                <li>レバレッジポイントの特定</li>
                <li>究極のゴール設定</li>
              </ul>
            </div>

            <div>
              <h3 className="text-xl font-heading mb-6">会社情報</h3>
              <div className="text-gray-300 font-body">
                <p className="mb-3">E-spiral合同会社</p>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-700 mt-12 pt-8 text-center text-gray-400 font-ui">
            <p>&copy; 2024 E-spiral合同会社. All Rights Reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
